package com.example.guia.guiaapp.model;

/**
 * Created by samuel on 24/08/2017.
 */

public class Temas
{
    private Integer ID_Tem;
    private String nome_tem;

    public Integer getID_Tem() {
        return ID_Tem;
    }

    public void setID_Tem(Integer ID_Tem) {
        this.ID_Tem = ID_Tem;
    }

    public String getNome_tem() {
        return nome_tem;
    }

    public void setNome_tem(String nome_tem) {
        this.nome_tem = nome_tem;
    }
}
