//Passagem de parametro por valor

#include <stdio.h>

int teste(int x)
{
  int z;
  z = x*2;
  return z;
}

main()
{
      int a, b, x=5, y;
      
      y=teste(x);
      
      printf("x = %d",y);
      system("pause>nul");
}
