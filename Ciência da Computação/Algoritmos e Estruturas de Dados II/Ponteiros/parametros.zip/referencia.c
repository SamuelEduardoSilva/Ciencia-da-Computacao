//Passagem de par�metro por refer�ncia

#include <stdio.h>

int teste(int *x)
{
  int y;  
  y = *x * 2;  
  *x = y; 
}

main()
{
      int a, b, x=5;
      
      teste(&x);
      
      printf("x = %d",x);
      system("pause>nul");
}
