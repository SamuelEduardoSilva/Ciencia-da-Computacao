﻿


namespace BrasilCardAppLojistaXamarin.Droid
{
    public class Rota
    {
        public string local;
        public string horario;
        public string data;
        public string veiculo;

        public Rota(string local, string horario, string data, string veiculo)
        {
            this.local = local;
            this.horario = horario;
            this.data = data;
            this.veiculo = veiculo;
        }




    }
}
